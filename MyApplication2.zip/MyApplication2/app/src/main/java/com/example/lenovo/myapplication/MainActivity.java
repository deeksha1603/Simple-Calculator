package com.example.lenovo.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
  EditText et1;
  Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16,b17;
  boolean mAddition, mSubtract, mMultiplication, mDivision ;
  float Value1,Value2;
  //String[] Value=new String[18];
  //  int c = 0;
   // int ans=0;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.button4);
        b5=(Button)findViewById(R.id.button6);
        b6=(Button)findViewById(R.id.button7);
        b7=(Button)findViewById(R.id.button8);
        b8=(Button)findViewById(R.id.button9);
        b9=(Button)findViewById(R.id.button10);
        b10=(Button)findViewById(R.id.button11);
        b11=(Button)findViewById(R.id.button12);
        b12=(Button)findViewById(R.id.button13);
        b13=(Button)findViewById(R.id.button14);
        b14=(Button)findViewById(R.id.button15);
        b15=(Button)findViewById(R.id.button16);
        b16=(Button)findViewById(R.id.button5);
        b17=(Button)findViewById(R.id.button17);

        et1=(EditText)findViewById(R.id.editText2);

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"0");
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"1");
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"2");
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"3");
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"4");
            }
        });
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"5");
            }
        });
        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"6");
            }
        });
        b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"7");
            }
        });
        b13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"8");
            }
        });
        b14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"9");
            }
        });
        b16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+".");
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
             Value1 = Float.parseFloat(et1.getText() + "");
             mMultiplication=true;
             et1.setText(null);
            }
        });

        b3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Value1 = Float.parseFloat(et1.getText() + "");
                mAddition=true;
                et1.setText(null);
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Value1 = Float.parseFloat(et1.getText() + "");
                mSubtract=true;
                et1.setText(null);
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Value1 = Float.parseFloat(et1.getText() + "");
                mDivision=true;
                et1.setText(null);
            }
        });

        b15.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

               /*the below commented code is for the calculation of more than two numbers given in the edittext
               String Value = (et1.getText().toString());
               String[] a = Value.split("\\+\\*\\-\\/");
               int lengths=a.length;
                ans=add(a);
                String newone=Integer.toString(ans);
                et1.setText(newone);
                int aa=Integer.parseInt(a[0]);
                int bb=Integer.parseInt(a[1]);
                int finalanswer;
                int i;
                int bb;
                for(i=0;i<lengths;i++)
                 {
                  int aa=Integer.parseInt(a[i]);
                  if(i==lengths-1)
                  {
                      bb=0;
                  }
                  else
                  {
                      bb = Integer.parseInt(a[i + 1]);
                  }
                   String nn=Integer.toString(aa);
                  ans=add(aa,bb,ans);
                  if(i==lengths-1)
                  {
                      String newone=Integer.toString(ans);
                      et1.setText(newone);
                  }

               }
                 int finalanswer= add(aa,bb);
                String finalanswer1= addall(String a);
                String newone=Integer.toString(finalanswer);
                et1.setText(newone);
                */

               Value2 = Float.parseFloat(et1.getText()+" ");

                    if (mSubtract == true)
                    {
                    et1.setText(Value1 - Value2 + "" );
                    mSubtract=false;
                     }
                    if (mAddition == true){
                    et1.setText(Value1 + Value2 +"");
                    mAddition=false;
                     }
                    if (mMultiplication == true){
                    et1.setText(Value1 * Value2 +"");
                    mMultiplication=false;
                    }
                    if (mDivision == true){
                    et1.setText(Value1 / Value2 +"");
                    mDivision=false;
                   }

             }

        });


        b17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText("");
            }
        });
    }

  /*this below commented add function is for the calculation of more than two numbers in the edittext
   public  int add(String[] a)
    {
int total=0;
       for(int i=0;i<a.length;i++)
       {
           total=total+Integer.parseInt(a[i]);
       }
     return total;
    }*/


/*the below commented code is the code for the calculator with just two edittexts for entering numbers and performing operations on pressing the
required operators
        b1.setOnClickListener(new View.OnClickListener() {
            Float l1,l2,l3;
            @Override
            public void onClick(View v) {

               l1=Float.parseFloat(et1.getText().toString());
               l2=Float.parseFloat(et2.getText().toString());
               add(l1,l2);
            }
            public void add(Float l1,Float l2)
            {
                l3=l1+l2;
                et3.setText(Float.toString(l3));
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float l1,l2,l3;
                l1=Float.parseFloat(et1.getText().toString());
                l2=Float.parseFloat(et2.getText().toString());
                l3=l1-l2;
                et3.setText(Float.toString(l3));
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float l1,l2,l3;
                l1=Float.parseFloat(et1.getText().toString());
                l2=Float.parseFloat(et2.getText().toString());
                l3=l1*l2;
                et3.setText(Float.toString(l3));
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float l1,l2,l3;
                l1=Float.parseFloat(et1.getText().toString());
                l2=Float.parseFloat(et2.getText().toString());
                l3=l1/l2;
                et3.setText(Float.toString(l3));
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float l1,l2,l3;
                l1=Float.parseFloat(et1.getText().toString());
                l2=Float.parseFloat(et2.getText().toString());
                l3=l1%l2;
                et3.setText(Float.toString(l3));
            }
        });*/


    }

